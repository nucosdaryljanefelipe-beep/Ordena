﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.pnlUpcomingEvents = New System.Windows.Forms.Panel()
        Me.flpEvents = New System.Windows.Forms.FlowLayoutPanel()
        Me.lblEventDate = New System.Windows.Forms.Label()
        Me.lblEventName = New System.Windows.Forms.Label()
        Me.lblEventDescription = New System.Windows.Forms.Label()
        Me.cboCategory = New System.Windows.Forms.ComboBox()
        Me.lblUpcomingTitle = New System.Windows.Forms.Label()
        Me.btnAdd = New System.Windows.Forms.Button()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.pnlCalen = New System.Windows.Forms.Panel()
        Me.tlpCalendar = New System.Windows.Forms.TableLayoutPanel()
        Me.calenDetail = New System.Windows.Forms.Label()
        Me.calenNxt = New System.Windows.Forms.Button()
        Me.calenPrev = New System.Windows.Forms.Button()
        Me.pnlUpcomingEvents.SuspendLayout()
        Me.flpEvents.SuspendLayout()
        Me.pnlCalen.SuspendLayout()
        Me.SuspendLayout()
        '
        'pnlUpcomingEvents
        '
        Me.pnlUpcomingEvents.BackColor = System.Drawing.Color.FromArgb(CType(CType(166, Byte), Integer), CType(CType(161, Byte), Integer), CType(CType(225, Byte), Integer))
        Me.pnlUpcomingEvents.Controls.Add(Me.flpEvents)
        Me.pnlUpcomingEvents.Controls.Add(Me.cboCategory)
        Me.pnlUpcomingEvents.Controls.Add(Me.lblUpcomingTitle)
        Me.pnlUpcomingEvents.Controls.Add(Me.btnAdd)
        Me.pnlUpcomingEvents.Controls.Add(Me.Label2)
        Me.pnlUpcomingEvents.Controls.Add(Me.Label1)
        Me.pnlUpcomingEvents.Dock = System.Windows.Forms.DockStyle.Left
        Me.pnlUpcomingEvents.ForeColor = System.Drawing.Color.FromArgb(CType(CType(166, Byte), Integer), CType(CType(161, Byte), Integer), CType(CType(225, Byte), Integer))
        Me.pnlUpcomingEvents.Location = New System.Drawing.Point(0, 0)
        Me.pnlUpcomingEvents.Margin = New System.Windows.Forms.Padding(4)
        Me.pnlUpcomingEvents.Name = "pnlUpcomingEvents"
        Me.pnlUpcomingEvents.Size = New System.Drawing.Size(688, 853)
        Me.pnlUpcomingEvents.TabIndex = 0
        '
        'flpEvents
        '
        Me.flpEvents.AutoScroll = True
        Me.flpEvents.Controls.Add(Me.lblEventDate)
        Me.flpEvents.Controls.Add(Me.lblEventName)
        Me.flpEvents.Controls.Add(Me.lblEventDescription)
        Me.flpEvents.FlowDirection = System.Windows.Forms.FlowDirection.TopDown
        Me.flpEvents.Font = New System.Drawing.Font("Segoe UI", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.flpEvents.Location = New System.Drawing.Point(32, 228)
        Me.flpEvents.Name = "flpEvents"
        Me.flpEvents.Size = New System.Drawing.Size(625, 405)
        Me.flpEvents.TabIndex = 6
        Me.flpEvents.WrapContents = False
        '
        'lblEventDate
        '
        Me.lblEventDate.AutoSize = True
        Me.lblEventDate.Location = New System.Drawing.Point(3, 0)
        Me.lblEventDate.Name = "lblEventDate"
        Me.lblEventDate.Size = New System.Drawing.Size(0, 28)
        Me.lblEventDate.TabIndex = 0
        '
        'lblEventName
        '
        Me.lblEventName.AutoSize = True
        Me.lblEventName.Location = New System.Drawing.Point(3, 28)
        Me.lblEventName.Name = "lblEventName"
        Me.lblEventName.Size = New System.Drawing.Size(0, 28)
        Me.lblEventName.TabIndex = 1
        '
        'lblEventDescription
        '
        Me.lblEventDescription.AutoSize = True
        Me.lblEventDescription.Location = New System.Drawing.Point(3, 56)
        Me.lblEventDescription.Name = "lblEventDescription"
        Me.lblEventDescription.Size = New System.Drawing.Size(0, 28)
        Me.lblEventDescription.TabIndex = 2
        '
        'cboCategory
        '
        Me.cboCategory.BackColor = System.Drawing.Color.FromArgb(CType(CType(198, Byte), Integer), CType(CType(201, Byte), Integer), CType(CType(227, Byte), Integer))
        Me.cboCategory.Font = New System.Drawing.Font("Segoe UI", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cboCategory.ForeColor = System.Drawing.Color.FromArgb(CType(CType(57, Byte), Integer), CType(CType(60, Byte), Integer), CType(CType(104, Byte), Integer))
        Me.cboCategory.FormattingEnabled = True
        Me.cboCategory.Location = New System.Drawing.Point(470, 137)
        Me.cboCategory.Name = "cboCategory"
        Me.cboCategory.Size = New System.Drawing.Size(172, 49)
        Me.cboCategory.TabIndex = 5
        '
        'lblUpcomingTitle
        '
        Me.lblUpcomingTitle.AutoSize = True
        Me.lblUpcomingTitle.Font = New System.Drawing.Font("Goudy Old Style", 25.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblUpcomingTitle.ForeColor = System.Drawing.Color.FromArgb(CType(CType(57, Byte), Integer), CType(CType(60, Byte), Integer), CType(CType(104, Byte), Integer))
        Me.lblUpcomingTitle.Location = New System.Drawing.Point(44, 137)
        Me.lblUpcomingTitle.Name = "lblUpcomingTitle"
        Me.lblUpcomingTitle.Size = New System.Drawing.Size(0, 51)
        Me.lblUpcomingTitle.TabIndex = 4
        '
        'btnAdd
        '
        Me.btnAdd.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(CType(CType(57, Byte), Integer), CType(CType(60, Byte), Integer), CType(CType(104, Byte), Integer))
        Me.btnAdd.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(57, Byte), Integer), CType(CType(60, Byte), Integer), CType(CType(104, Byte), Integer))
        Me.btnAdd.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(235, Byte), Integer), CType(CType(238, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.btnAdd.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnAdd.Font = New System.Drawing.Font("Consolas", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnAdd.ForeColor = System.Drawing.Color.FromArgb(CType(CType(57, Byte), Integer), CType(CType(60, Byte), Integer), CType(CType(104, Byte), Integer))
        Me.btnAdd.Location = New System.Drawing.Point(0, 689)
        Me.btnAdd.Name = "btnAdd"
        Me.btnAdd.Size = New System.Drawing.Size(695, 79)
        Me.btnAdd.TabIndex = 3
        Me.btnAdd.Text = " Add                                                   >"
        Me.btnAdd.UseVisualStyleBackColor = True
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Segoe UI", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.ForeColor = System.Drawing.Color.FromArgb(CType(CType(57, Byte), Integer), CType(CType(60, Byte), Integer), CType(CType(104, Byte), Integer))
        Me.Label2.Location = New System.Drawing.Point(381, 50)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(136, 56)
        Me.Label2.TabIndex = 1
        Me.Label2.Text = "your calendar " & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "find its way"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Segoe UI", 36.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.Color.FromArgb(CType(CType(57, Byte), Integer), CType(CType(60, Byte), Integer), CType(CType(104, Byte), Integer))
        Me.Label1.Location = New System.Drawing.Point(118, 40)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(257, 81)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Ordena:"
        '
        'pnlCalen
        '
        Me.pnlCalen.Controls.Add(Me.tlpCalendar)
        Me.pnlCalen.Controls.Add(Me.calenDetail)
        Me.pnlCalen.Controls.Add(Me.calenNxt)
        Me.pnlCalen.Controls.Add(Me.calenPrev)
        Me.pnlCalen.Dock = System.Windows.Forms.DockStyle.Right
        Me.pnlCalen.Location = New System.Drawing.Point(689, 0)
        Me.pnlCalen.Name = "pnlCalen"
        Me.pnlCalen.Size = New System.Drawing.Size(793, 853)
        Me.pnlCalen.TabIndex = 1
        '
        'tlpCalendar
        '
        Me.tlpCalendar.AutoScroll = True
        Me.tlpCalendar.ColumnCount = 7
        Me.tlpCalendar.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 14.28571!))
        Me.tlpCalendar.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 14.28571!))
        Me.tlpCalendar.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 14.28571!))
        Me.tlpCalendar.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 14.28571!))
        Me.tlpCalendar.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 14.28571!))
        Me.tlpCalendar.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 14.28571!))
        Me.tlpCalendar.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 14.28571!))
        Me.tlpCalendar.Font = New System.Drawing.Font("Segoe UI", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tlpCalendar.ForeColor = System.Drawing.Color.FromArgb(CType(CType(57, Byte), Integer), CType(CType(60, Byte), Integer), CType(CType(104, Byte), Integer))
        Me.tlpCalendar.Location = New System.Drawing.Point(42, 165)
        Me.tlpCalendar.Name = "tlpCalendar"
        Me.tlpCalendar.RowCount = 7
        Me.tlpCalendar.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 14.28571!))
        Me.tlpCalendar.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 14.28571!))
        Me.tlpCalendar.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 14.28571!))
        Me.tlpCalendar.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 14.28571!))
        Me.tlpCalendar.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 14.28571!))
        Me.tlpCalendar.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 14.28571!))
        Me.tlpCalendar.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 14.28571!))
        Me.tlpCalendar.Size = New System.Drawing.Size(723, 578)
        Me.tlpCalendar.TabIndex = 13
        '
        'calenDetail
        '
        Me.calenDetail.AutoSize = True
        Me.calenDetail.Font = New System.Drawing.Font("Goudy Old Style", 36.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.calenDetail.ForeColor = System.Drawing.Color.FromArgb(CType(CType(57, Byte), Integer), CType(CType(60, Byte), Integer), CType(CType(104, Byte), Integer))
        Me.calenDetail.Location = New System.Drawing.Point(42, 27)
        Me.calenDetail.Name = "calenDetail"
        Me.calenDetail.Size = New System.Drawing.Size(0, 69)
        Me.calenDetail.TabIndex = 10
        '
        'calenNxt
        '
        Me.calenNxt.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(CType(CType(235, Byte), Integer), CType(CType(238, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.calenNxt.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.calenNxt.ForeColor = System.Drawing.Color.FromArgb(CType(CType(57, Byte), Integer), CType(CType(60, Byte), Integer), CType(CType(104, Byte), Integer))
        Me.calenNxt.Location = New System.Drawing.Point(726, 40)
        Me.calenNxt.Name = "calenNxt"
        Me.calenNxt.Size = New System.Drawing.Size(39, 38)
        Me.calenNxt.TabIndex = 9
        Me.calenNxt.Text = "▶"
        Me.calenNxt.UseVisualStyleBackColor = True
        '
        'calenPrev
        '
        Me.calenPrev.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(CType(CType(235, Byte), Integer), CType(CType(238, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.calenPrev.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.calenPrev.ForeColor = System.Drawing.Color.FromArgb(CType(CType(57, Byte), Integer), CType(CType(60, Byte), Integer), CType(CType(104, Byte), Integer))
        Me.calenPrev.Location = New System.Drawing.Point(661, 40)
        Me.calenPrev.Name = "calenPrev"
        Me.calenPrev.Size = New System.Drawing.Size(39, 38)
        Me.calenPrev.TabIndex = 8
        Me.calenPrev.Text = "◀"
        Me.calenPrev.UseVisualStyleBackColor = True
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(11.0!, 23.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.FromArgb(CType(CType(235, Byte), Integer), CType(CType(238, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.ClientSize = New System.Drawing.Size(1482, 853)
        Me.Controls.Add(Me.pnlCalen)
        Me.Controls.Add(Me.pnlUpcomingEvents)
        Me.Font = New System.Drawing.Font("Goudy Old Style", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Margin = New System.Windows.Forms.Padding(4)
        Me.Name = "Form1"
        Me.Text = "Form1"
        Me.pnlUpcomingEvents.ResumeLayout(False)
        Me.pnlUpcomingEvents.PerformLayout()
        Me.flpEvents.ResumeLayout(False)
        Me.flpEvents.PerformLayout()
        Me.pnlCalen.ResumeLayout(False)
        Me.pnlCalen.PerformLayout()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents pnlUpcomingEvents As Panel
    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents btnAdd As Button
    Friend WithEvents pnlCalen As Panel
    Friend WithEvents calenDetail As Label
    Friend WithEvents calenNxt As Button
    Friend WithEvents calenPrev As Button
    Friend WithEvents tlpCalendar As TableLayoutPanel
    Friend WithEvents cboCategory As ComboBox
    Friend WithEvents lblUpcomingTitle As Label
    Friend WithEvents flpEvents As FlowLayoutPanel
    Friend WithEvents lblEventDate As Label
    Friend WithEvents lblEventName As Label
    Friend WithEvents lblEventDescription As Label
End Class
