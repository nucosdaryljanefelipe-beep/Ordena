﻿Imports MySql.Data.MySqlClient

Module Database
    Public Conn As MySqlConnection

    Public Sub OpenDB()
        If Conn Is Nothing Then
            Conn = New MySqlConnection("server=localhost; user id=root; password=; database=ordena;")
        End If
        If Conn.State <> ConnectionState.Open Then Conn.Open()
    End Sub

    Public Sub CloseDB()
        If Conn IsNot Nothing AndAlso Conn.State = ConnectionState.Open Then Conn.Close()
    End Sub
End Module
