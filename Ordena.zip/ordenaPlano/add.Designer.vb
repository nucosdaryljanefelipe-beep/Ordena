﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class add
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.EventName = New System.Windows.Forms.TextBox()
        Me.DateTimePicker = New System.Windows.Forms.DateTimePicker()
        Me.Category = New System.Windows.Forms.ComboBox()
        Me.description = New System.Windows.Forms.TextBox()
        Me.ColorDialog1 = New System.Windows.Forms.ColorDialog()
        Me.btnCancel = New System.Windows.Forms.Button()
        Me.btnSave = New System.Windows.Forms.Button()
        Me.BtnChangeColor = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Goudy Old Style", 28.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(12, 21)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(326, 54)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Add New Event"
        '
        'EventName
        '
        Me.EventName.BackColor = System.Drawing.Color.FromArgb(CType(CType(166, Byte), Integer), CType(CType(161, Byte), Integer), CType(CType(225, Byte), Integer))
        Me.EventName.Font = New System.Drawing.Font("Segoe UI", 19.8!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.EventName.ForeColor = System.Drawing.Color.FromArgb(CType(CType(57, Byte), Integer), CType(CType(60, Byte), Integer), CType(CType(104, Byte), Integer))
        Me.EventName.Location = New System.Drawing.Point(21, 129)
        Me.EventName.Multiline = True
        Me.EventName.Name = "EventName"
        Me.EventName.Size = New System.Drawing.Size(434, 52)
        Me.EventName.TabIndex = 1
        '
        'DateTimePicker
        '
        Me.DateTimePicker.CalendarForeColor = System.Drawing.Color.FromArgb(CType(CType(235, Byte), Integer), CType(CType(238, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.DateTimePicker.CalendarMonthBackground = System.Drawing.Color.FromArgb(CType(CType(57, Byte), Integer), CType(CType(60, Byte), Integer), CType(CType(104, Byte), Integer))
        Me.DateTimePicker.Font = New System.Drawing.Font("Segoe UI", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.DateTimePicker.Location = New System.Drawing.Point(21, 199)
        Me.DateTimePicker.Name = "DateTimePicker"
        Me.DateTimePicker.Size = New System.Drawing.Size(214, 34)
        Me.DateTimePicker.TabIndex = 2
        '
        'Category
        '
        Me.Category.BackColor = System.Drawing.Color.FromArgb(CType(CType(166, Byte), Integer), CType(CType(161, Byte), Integer), CType(CType(225, Byte), Integer))
        Me.Category.Font = New System.Drawing.Font("Segoe UI", 12.0!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Category.ForeColor = System.Drawing.Color.FromArgb(CType(CType(57, Byte), Integer), CType(CType(60, Byte), Integer), CType(CType(104, Byte), Integer))
        Me.Category.FormattingEnabled = True
        Me.Category.Location = New System.Drawing.Point(241, 199)
        Me.Category.Name = "Category"
        Me.Category.Size = New System.Drawing.Size(213, 36)
        Me.Category.TabIndex = 3
        '
        'description
        '
        Me.description.BackColor = System.Drawing.Color.FromArgb(CType(CType(166, Byte), Integer), CType(CType(161, Byte), Integer), CType(CType(225, Byte), Integer))
        Me.description.Font = New System.Drawing.Font("Segoe UI", 18.0!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.description.ForeColor = System.Drawing.Color.FromArgb(CType(CType(57, Byte), Integer), CType(CType(60, Byte), Integer), CType(CType(104, Byte), Integer))
        Me.description.Location = New System.Drawing.Point(21, 253)
        Me.description.Multiline = True
        Me.description.Name = "description"
        Me.description.Size = New System.Drawing.Size(434, 52)
        Me.description.TabIndex = 4
        Me.description.Text = "Add Description (optional)"
        '
        'btnCancel
        '
        Me.btnCancel.BackColor = System.Drawing.Color.FromArgb(CType(CType(57, Byte), Integer), CType(CType(60, Byte), Integer), CType(CType(104, Byte), Integer))
        Me.btnCancel.FlatAppearance.BorderSize = 0
        Me.btnCancel.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Red
        Me.btnCancel.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnCancel.Font = New System.Drawing.Font("Segoe UI", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnCancel.ForeColor = System.Drawing.Color.FromArgb(CType(CType(235, Byte), Integer), CType(CType(238, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.btnCancel.Location = New System.Drawing.Point(109, 416)
        Me.btnCancel.Name = "btnCancel"
        Me.btnCancel.Size = New System.Drawing.Size(106, 45)
        Me.btnCancel.TabIndex = 5
        Me.btnCancel.Text = "Cancel"
        Me.btnCancel.UseVisualStyleBackColor = False
        '
        'btnSave
        '
        Me.btnSave.BackColor = System.Drawing.Color.FromArgb(CType(CType(57, Byte), Integer), CType(CType(60, Byte), Integer), CType(CType(104, Byte), Integer))
        Me.btnSave.FlatAppearance.BorderSize = 0
        Me.btnSave.FlatAppearance.MouseDownBackColor = System.Drawing.Color.LightGreen
        Me.btnSave.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnSave.Font = New System.Drawing.Font("Segoe UI", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnSave.ForeColor = System.Drawing.Color.FromArgb(CType(CType(235, Byte), Integer), CType(CType(238, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.btnSave.Location = New System.Drawing.Point(241, 416)
        Me.btnSave.Name = "btnSave"
        Me.btnSave.Size = New System.Drawing.Size(106, 45)
        Me.btnSave.TabIndex = 6
        Me.btnSave.Text = "Save"
        Me.btnSave.UseVisualStyleBackColor = False
        '
        'BtnChangeColor
        '
        Me.BtnChangeColor.BackColor = System.Drawing.Color.FromArgb(CType(CType(166, Byte), Integer), CType(CType(161, Byte), Integer), CType(CType(225, Byte), Integer))
        Me.BtnChangeColor.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.BtnChangeColor.Font = New System.Drawing.Font("Segoe UI", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtnChangeColor.ForeColor = System.Drawing.Color.FromArgb(CType(CType(57, Byte), Integer), CType(CType(60, Byte), Integer), CType(CType(104, Byte), Integer))
        Me.BtnChangeColor.Location = New System.Drawing.Point(21, 311)
        Me.BtnChangeColor.Name = "BtnChangeColor"
        Me.BtnChangeColor.Size = New System.Drawing.Size(214, 45)
        Me.BtnChangeColor.TabIndex = 7
        Me.BtnChangeColor.Text = "Change color?"
        Me.BtnChangeColor.UseVisualStyleBackColor = False
        '
        'add
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(11.0!, 23.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.FromArgb(CType(CType(166, Byte), Integer), CType(CType(161, Byte), Integer), CType(CType(225, Byte), Integer))
        Me.ClientSize = New System.Drawing.Size(467, 491)
        Me.Controls.Add(Me.BtnChangeColor)
        Me.Controls.Add(Me.btnSave)
        Me.Controls.Add(Me.btnCancel)
        Me.Controls.Add(Me.description)
        Me.Controls.Add(Me.Category)
        Me.Controls.Add(Me.DateTimePicker)
        Me.Controls.Add(Me.EventName)
        Me.Controls.Add(Me.Label1)
        Me.Font = New System.Drawing.Font("Goudy Old Style", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ForeColor = System.Drawing.Color.FromArgb(CType(CType(57, Byte), Integer), CType(CType(60, Byte), Integer), CType(CType(104, Byte), Integer))
        Me.Margin = New System.Windows.Forms.Padding(4)
        Me.Name = "add"
        Me.Text = "add"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Label1 As Label
    Friend WithEvents EventName As TextBox
    Friend WithEvents DateTimePicker As DateTimePicker
    Friend WithEvents Category As ComboBox
    Friend WithEvents description As TextBox
    Friend WithEvents ColorDialog1 As ColorDialog
    Friend WithEvents btnCancel As Button
    Friend WithEvents btnSave As Button
    Friend WithEvents BtnChangeColor As Button
End Class
