﻿Imports MySql.Data.MySqlClient
Imports System.Drawing

Public Class add
    Private editId As Integer = -1
    Private presetDate As Date = Date.Today
    Public Event EventSaved As Action
    Private selColor As Color = Color.LightSkyBlue

    ' ---- NEW CONSTRUCTOR (needed for Add/Edit) ----
    Public Sub New(Optional id As Integer = -1, Optional d As Date = Nothing)
        InitializeComponent()
        editId = id
        If d <> Nothing Then presetDate = d
    End Sub

    Private Shadows Sub add_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Category.Items.Clear()
        Category.Items.AddRange({"Academic", "Business", "Family", "Friends", "Holiday", "Personal"})
        Category.DropDownStyle = ComboBoxStyle.DropDownList
        If Category.Items.Count > 0 Then Category.SelectedIndex = 0

        DateTimePicker.Format = DateTimePickerFormat.Custom
        DateTimePicker.CustomFormat = "yyyy-MM-dd HH:mm:ss"

        BtnChangeColor.BackColor = selColor
        btnSave.BringToFront()
        btnCancel.BringToFront()
        Me.AcceptButton = btnSave

        ' ---------- PREFILL DATE (Add Mode) ----------
        DateTimePicker.Value = presetDate

        ' ---------- LOAD EVENT DATA (Edit Mode) ----------
        If editId <> -1 Then
            Try
                Database.OpenDB()
                Dim sql = "SELECT title, edate, category, description, color FROM events WHERE id=@id"
                Using cmd As New MySqlCommand(sql, Database.Conn)
                    cmd.Parameters.AddWithValue("@id", editId)
                    Using r = cmd.ExecuteReader()
                        If r.Read() Then
                            EventName.Text = r.GetString("title")
                            DateTimePicker.Value = r.GetDateTime("edate")
                            Category.Text = r.GetString("category")
                            description.Text = r.GetString("description")
                            selColor = ColorTranslator.FromHtml(r.GetString("color"))
                            BtnChangeColor.BackColor = selColor
                        End If
                    End Using
                End Using
            Catch ex As Exception
                MessageBox.Show("Error loading event for edit: " & ex.Message)
            Finally
                Database.CloseDB()
            End Try
        End If
    End Sub

    Private Sub BtnChangeColor_Click(sender As Object, e As EventArgs) Handles BtnChangeColor.Click
        If ColorDialog1.ShowDialog() = DialogResult.OK Then
            selColor = ColorDialog1.Color
            BtnChangeColor.BackColor = selColor
        End If
    End Sub

    Private Sub btnCancel_Click(sender As Object, e As EventArgs) Handles btnCancel.Click
        MessageBox.Show("Exiting...", "Cancelled", MessageBoxButtons.OK, MessageBoxIcon.Information)
        Me.Close()
    End Sub

    Private Sub btnSave_Click(sender As Object, e As EventArgs) Handles btnSave.Click
        If EventName.Text.Trim() = "" Then
            MessageBox.Show("Please enter a title.", "Missing title", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            Exit Sub
        End If

        Dim sql As String =
            If(editId = -1,
               "INSERT INTO events (title,edate,category,description,color) VALUES (@t,@d,@c,@ds,@col)",
               "UPDATE events SET title=@t, edate=@d, category=@c, description=@ds, color=@col WHERE id=@id")

        Try
            Database.OpenDB()
            Using cmd As New MySqlCommand(sql, Database.Conn)
                cmd.Parameters.AddWithValue("@t", EventName.Text.Trim())
                cmd.Parameters.AddWithValue("@d", DateTimePicker.Value.ToString("yyyy-MM-dd HH:mm:ss"))
                cmd.Parameters.AddWithValue("@c", Category.Text)
                cmd.Parameters.AddWithValue("@ds", description.Text.Trim())
                cmd.Parameters.AddWithValue("@col", ColorTranslator.ToHtml(selColor))
                If editId <> -1 Then cmd.Parameters.AddWithValue("@id", editId)
                cmd.ExecuteNonQuery()
            End Using
            MessageBox.Show("Event saved!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information)
            RaiseEvent EventSaved()
            Me.Close()
        Catch ex As Exception
            MessageBox.Show("Save failed: " & ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        Finally
            Database.CloseDB()
        End Try
    End Sub

End Class
