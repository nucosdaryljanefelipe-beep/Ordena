﻿Imports MySql.Data.MySqlClient
Imports System.Drawing

Public Class Form1
    Dim currentDate As Date = Date.Today
    Dim eventDates As New Dictionary(Of Date, (Integer, String, Color, String, String))

    Private firstLoad As Boolean = True
    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        cboCategory.Items.AddRange({"All", "Academic", "Business", "Family", "Friends", "Holiday", "Personal"})
        cboCategory.SelectedIndex = 0

        LoadEventsFromDB()
        LoadCalendar()
        LoadUpcoming()
        firstLoad = False
    End Sub

    ' ---------------- LOAD DB ----------------
    Private Sub LoadEventsFromDB()
        eventDates.Clear()
        Try
            Database.OpenDB()
            Using cmd As New MySqlCommand("SELECT id,title,edate,category,description,color FROM events", Database.Conn)
                Using r = cmd.ExecuteReader()
                    While r.Read()
                        Dim d = r.GetDateTime("edate").Date
                        Dim title = r.GetString("title")
                        Dim col = ColorTranslator.FromHtml(r.GetString("color"))
                        eventDates(d) = (r.GetInt32("id"), title, col, r.GetString("category"), r.GetString("description"))
                    End While
                End Using
            End Using
        Catch ex As Exception
            MessageBox.Show(ex.Message)
        Finally
            Database.CloseDB()
        End Try
    End Sub

    ' ---------------- CALENDAR ----------------
    Private Sub LoadCalendar()
        tlpCalendar.Controls.Clear()
        calenDetail.Text = currentDate.ToString("MMMM yyyy")

        Dim dow = {"Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"}
        For c = 0 To 6
            tlpCalendar.Controls.Add(New Label With {
                .Text = dow(c),
                .Dock = DockStyle.Fill,
                .TextAlign = ContentAlignment.MiddleCenter,
                .ForeColor = If(c = 0, Color.Red, Color.FromArgb(57, 60, 104)),
                .Font = New Font("Goudy Old Style", 11, FontStyle.Bold)
            }, c, 0)
        Next

        Dim first = New Date(currentDate.Year, currentDate.Month, 1)
        Dim total = Date.DaysInMonth(currentDate.Year, currentDate.Month)
        Dim startCol = CInt(first.DayOfWeek)
        Dim d = 1

        For r = 1 To 6
            For c = 0 To 6
                Dim lbl As New Label With {
                    .Dock = DockStyle.Fill,
                    .TextAlign = ContentAlignment.TopRight,
                    .Font = New Font("Goudy Old Style", 10),
                    .ForeColor = If(c = 0, Color.Red, Color.FromArgb(57, 60, 104)),
                    .BackColor = Color.FromArgb(235, 238, 255),
                    .Padding = New Padding(2)
                }

                If (r = 1 AndAlso c < startCol) OrElse d > total Then
                    lbl.Text = ""
                Else
                    lbl.Text = d.ToString()
                    Dim thisDate As New Date(currentDate.Year, currentDate.Month, d)

                    If eventDates.ContainsKey(thisDate) Then
                        ' Show event title under the number
                        lbl.Text &= vbCrLf & eventDates(thisDate).Item2
                        lbl.ForeColor = eventDates(thisDate).Item3
                        lbl.Font = New Font("Goudy Old Style", 10, FontStyle.Bold)
                    End If

                    AddHandler lbl.Click, AddressOf DayLabel_Click
                    d += 1
                End If

                tlpCalendar.Controls.Add(lbl, c, r)
            Next
        Next
    End Sub

    ' ---------------- CLICK DATE ----------------
    Private Sub DayLabel_Click(sender As Object, e As EventArgs)
        Dim lbl = DirectCast(sender, Label)
        If lbl.Text = "" Then Return

        Dim num = CInt(lbl.Text.Split(vbCrLf)(0))
        Dim selDate As Date = New Date(currentDate.Year, currentDate.Month, num)

        If eventDates.ContainsKey(selDate) Then
            Dim ev = eventDates(selDate)
            Dim msg = MessageBox.Show($"Edit (yes) or Delete (no) event '{ev.Item2}'?", "Event",
                                      MessageBoxButtons.YesNoCancel, MessageBoxIcon.Question,
                                      MessageBoxDefaultButton.Button3)

            If msg = DialogResult.Yes Then ' EDIT
                Dim f As New add(ev.Item1)  ' pass ID
                AddHandler f.EventSaved, Sub() RefreshAll()
                f.ShowDialog()
            ElseIf msg = DialogResult.No Then ' DELETE
                DeleteEvent(ev.Item1)
            End If
        Else
            Dim f As New add(Nothing, selDate) ' open add with date prefilled
            AddHandler f.EventSaved, Sub() RefreshAll()
            f.ShowDialog()
        End If
    End Sub

    ' ---------------- DELETE ----------------
    Private Sub DeleteEvent(id As Integer)
        If MessageBox.Show("Delete this event?", "Confirm", MessageBoxButtons.YesNo) = DialogResult.No Then Return
        Try
            Database.OpenDB()
            Using cmd As New MySqlCommand("DELETE FROM events WHERE id=@id", Database.Conn)
                cmd.Parameters.AddWithValue("@id", id)
                cmd.ExecuteNonQuery()
            End Using
        Finally
            Database.CloseDB()
        End Try
        RefreshAll()
    End Sub

    ' ---------------- REFRESH ----------------
    Private Sub RefreshAll()
        LoadEventsFromDB()
        LoadCalendar()
        LoadUpcoming()
    End Sub

    ' ---------------- CATEGORY FILTER ----------------
    Private Sub cboCategory_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cboCategory.SelectedIndexChanged
        LoadUpcoming()
    End Sub


    ' ---------------- UPCOMING ----------------
    Private Sub LoadUpcoming()
        flpEvents.Controls.Clear()
        lblUpcomingTitle.Text = currentDate.ToString("MMMM yyyy")

        Dim sel As String = If(cboCategory.SelectedItem IsNot Nothing, cboCategory.SelectedItem.ToString(), "All")

        Dim list = eventDates.Where(Function(k) k.Key.Month = currentDate.Month AndAlso
                                                k.Key.Year = currentDate.Year).
                              Select(Function(k) (k.Key, k.Value.Item2, k.Value.Item4, k.Value.Item5)).ToList()

        If sel <> "All" Then list = list.Where(Function(x) x.Item3 = sel).ToList()

        If list.Count = 0 Then
            Dim lbl As New Label With {
                .Text = "No upcoming events",
                .AutoSize = False,
                .Dock = DockStyle.Top,
                .TextAlign = ContentAlignment.MiddleCenter,
                .Height = 40,
                .ForeColor = Color.White,            ' make visible on dark background
                .Font = New Font("Goudy Old Style", 11, FontStyle.Bold),
                .Margin = New Padding(5)
            }
            flpEvents.Controls.Add(lbl)
            Return
        End If

        For Each eItem In list
            Dim pnl As New Panel With {.Width = flpEvents.Width - 20, .Height = 55, .BackColor = Color.FromArgb(60, 60, 110), .Margin = New Padding(5)}
            pnl.Controls.Add(New Label With {.Text = eItem.Item1.ToString("dd MMM yyyy"), .AutoSize = True, .Location = New Point(10, 6), .ForeColor = Color.LightGray})
            pnl.Controls.Add(New Label With {.Text = eItem.Item2, .AutoSize = True, .Location = New Point(120, 6), .ForeColor = Color.White})
            pnl.Controls.Add(New Label With {.Text = eItem.Item4, .AutoSize = True, .Location = New Point(120, 26), .ForeColor = Color.LightGray})
            flpEvents.Controls.Add(pnl)
        Next
    End Sub

    Private Sub btnAdd_Click(sender As Object, e As EventArgs) Handles btnAdd.Click
        Dim f As New add()
        AddHandler f.EventSaved, Sub() RefreshAll()
        f.ShowDialog()
    End Sub

    Private Sub calenPrev_Click(sender As Object, e As EventArgs) Handles calenPrev.Click
        currentDate = currentDate.AddMonths(-1) : RefreshAll()
    End Sub

    Private Sub calenNxt_Click(sender As Object, e As EventArgs) Handles calenNxt.Click
        currentDate = currentDate.AddMonths(1) : RefreshAll()
    End Sub

End Class
